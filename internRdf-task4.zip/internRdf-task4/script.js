document.addEventListener('DOMContentLoaded', () => {
    const display = document.getElementById('calc-display');
    const buttons = document.querySelectorAll('.calc-btn');
    let currentExpression = '';

    buttons.forEach((btn) => {
        btn.addEventListener('click', () => {
            const value = btn.getAttribute('data-value');
            const operators = ['+', '-', '*', '/'];

            if (btn.id === 'clear') {
                // Clear the display and reset expression
                currentExpression = '';
                display.textContent = '0';
            } else if (btn.id === 'equals') {
                // Calculate the result of the current expression
                try {
                    if (operators.includes(currentExpression.slice(-1))) {
                        // Prevent evaluating incomplete expressions like "3+"
                        display.textContent = 'Error';
                        currentExpression = '';
                    } else {
                        let result = eval(currentExpression) || '0';
                        result = Math.round(result * 100) / 100; // Round to 2 decimal places
                        currentExpression = String(result); // Convert result to a string
                        display.textContent = currentExpression;
                    }
                } catch {
                    display.textContent = 'Error';
                    currentExpression = '';
                }
            } else if (btn.id === 'delete') {
                // Remove the last character in the expression
                currentExpression = currentExpression.slice(0, -1);
                display.textContent = currentExpression || '0';
            } else {
                if (
                    operators.includes(value) &&
                    operators.includes(currentExpression.slice(-1))
                ) {
                    // Prevent consecutive operators
                    return;
                }

                if (value === '.') {
                    // Prevent multiple decimals in the current number
                    const lastNumberSegment = currentExpression.split(/[\+\-\*\/]/).pop();
                    if (lastNumberSegment.includes('.')) {
                        return; // Do not append another decimal
                    }
                }

                // Append the button value to the expression
                currentExpression += value;
                display.textContent = currentExpression;
            }
        });
    });
});
